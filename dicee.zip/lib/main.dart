import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  return runApp(
    MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.blue,
        appBar: AppBar(
          title: Center(
            child: Text('Dicee'),
          ),
          backgroundColor: Colors.blue,
        ),
        body: DiceePage(),
      ),
    ),
  );
}

class DiceePage extends StatefulWidget {
  @override
  _DiceePageState createState() => _DiceePageState();
}

class _DiceePageState extends State<DiceePage> {
  int leftDiceNumber = 1;
  int rightDiceNumber=1;
 void changeDice() {
   setState((){
     rightDiceNumber=Random().nextInt(6)+1;
     leftDiceNumber=Random().nextInt(6)+1;
   });
  }
        @override
  Widget build(BuildContext context) {
    return Center(
      child:Column(
        mainAxisAlignment:MainAxisAlignment.center,
        children:[
          Row(
        children: [
         Expanded(
        child:Padding(
          padding:EdgeInsets.all(16.0),
          child: Image.asset('images/dice$leftDiceNumber.png'),
        ),
         ),
          Expanded(
              child:Padding(
                padding:EdgeInsets.all(16.0),
                child:Image.asset('images/dice$rightDiceNumber.png'),
              ),
            ),
           
          ],
      ),
      SizedBox(
        height:20.0,
      ),
     FlatButton(
         onPressed:(){changeDice();},
        child:Padding(
         padding:EdgeInsets.all(
           5.0,
         ),
         child:Text(
          'Roll',style:TextStyle(fontSize: 20.0,color:Colors.blue,),
        ),
        ),
        color:Colors.white,
        textColor:Colors.blue,
        ),
      ],
      ),
    ); 
    }
}
